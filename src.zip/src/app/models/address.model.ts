export class Address{
    addressId : number;
    buildingNo : string;
    name: string;
    mobileNumber : string;
    city : string;
    state : string;
    country : string;
    pincode : string;
    address : string;
    setDefault : boolean;
}