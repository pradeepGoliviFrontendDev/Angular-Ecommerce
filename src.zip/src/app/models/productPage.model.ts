export class ProductPage{
    pageNumber : number;
    pageSize : number;
    sortBy : string;
}