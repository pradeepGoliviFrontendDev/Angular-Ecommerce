export class Category{
    catId: number;
    categoryName : string;
}