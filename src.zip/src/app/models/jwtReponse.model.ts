export class JwtResponse {
    token : string;
}