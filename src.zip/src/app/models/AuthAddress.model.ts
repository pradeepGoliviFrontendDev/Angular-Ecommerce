import { Address } from "./address.model";

export class AuthAddress{
    address : Address;
    token : string;
}